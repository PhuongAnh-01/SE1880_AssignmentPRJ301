/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Department;
import model.Employee;
import model.Plan;
import model.PlanCampain;
import model.SchedualCampaign;
import model.SchedualEmployee;

/**
 *
 * @author ADMIN
 */
public class SchedualEmployeeDao extends DBContext<SchedualEmployee> {

    @Override
    public void insert(SchedualEmployee entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(SchedualEmployee entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(SchedualEmployee entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<SchedualEmployee> list() {
        ArrayList<SchedualEmployee> list = new ArrayList<>();
        String sql = "SELECT *"
                + "FROM dbo.SchedualCampaign "
                + "JOIN dbo.SchedualEmployee ON SchedualEmployee.ScID = SchedualCampaign.ScID "
                + "JOIN dbo.Employee ON Employee.EmployeeID = SchedualEmployee.EmployeeID "
                + "JOIN dbo.PlanCampain ON PlanCampain.PlanCampnID = SchedualCampaign.PlanCampnID "
                + "JOIN dbo.[Plan] ON [Plan].PlanID = PlanCampain.PlanID "
                + "JOIN dbo.Department ON Department.DepartmentID = Plan.DepartmentID";

        try {
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                // Create Plan object
                Plan plan = new Plan(
                        rs.getInt("PlanID"),
                        rs.getString("PlanName"),
                        rs.getDate("StartDate"),
                        rs.getDate("EndDate"),
                        new Department(rs.getString("DepartmentName"))
                );

                // Create PlanCampain object
                PlanCampain planCampain = new PlanCampain(
                        rs.getInt("PlanCampnID"),
                        plan,
                        null, // Product can be set if needed
                        0, // Quantity if needed (adjust as per database schema)
                        0.0f // Cost if needed (adjust as per database schema)
                );

                // Create SchedualCampaign object
                SchedualCampaign schedualCampaign = new SchedualCampaign(
                        rs.getInt("ScID"),
                        planCampain,
                        rs.getDate("Date"),
                        rs.getString("Shift"),
                        rs.getInt("Quantity")
                );

                // Create Employee object
                Employee employee = new Employee(
                        rs.getInt("EmployeeID"),
                        rs.getString("EmployeeName"),
                        false, // Gender can be populated if needed
                        null, // Address can be populated if needed
                        null, // DOB can be populated if needed
                        null, // Role can be populated if needed
                        null, // Department can be populated if needed
                        null, // Salary can be populated if needed
                        null // Department object can be populated if needed
                );

                // Create SchedualEmployee object
                SchedualEmployee schedualEmployee = new SchedualEmployee(
                        0, // Set SchEmpID if needed (adjust as per schema)
                        schedualCampaign,
                        employee,
                        rs.getInt("Quantity")
                );

                list.add(schedualEmployee);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SchedualCampaignDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    @Override
    public SchedualEmployee get(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public static void main(String[] args) {
        // Khởi tạo đối tượng của lớp DAO để gọi phương thức list
        SchedualEmployeeDao dao = new SchedualEmployeeDao();

        // Gọi phương thức list và lưu kết quả vào biến
        ArrayList<SchedualEmployee> schedualEmployees = dao.list();

        // In ra danh sách kết quả để kiểm tra
        for (SchedualEmployee schedualEmployee : schedualEmployees) {
            System.out.println(schedualEmployee);
        }
    }

}
