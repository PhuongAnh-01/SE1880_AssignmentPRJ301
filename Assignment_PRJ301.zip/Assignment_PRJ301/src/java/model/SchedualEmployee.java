/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ADMIN
 */
public class SchedualEmployee {
    private int SchEmpID;
    private SchedualCampaign schedualCampaign;
    private Employee employee;
    private int quantity;

    public SchedualEmployee() {
    }

    public SchedualEmployee(int SchEmpID, SchedualCampaign schedualCampaign, Employee employee, int quantity) {
        this.SchEmpID = SchEmpID;
        this.schedualCampaign = schedualCampaign;
        this.employee = employee;
        this.quantity = quantity;
    }

    public int getSchEmpID() {
        return SchEmpID;
    }

    public void setSchEmpID(int SchEmpID) {
        this.SchEmpID = SchEmpID;
    }

    public SchedualCampaign getSchedualCampaign() {
        return schedualCampaign;
    }

    public void setSchedualCampaign(SchedualCampaign schedualCampaign) {
        this.schedualCampaign = schedualCampaign;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "SchedualEmployee{" + "SchEmpID=" + SchEmpID + ", schedualCampaign=" + schedualCampaign + ", employee=" + employee + ", quantity=" + quantity + '}';
    }
    
    
    
}
